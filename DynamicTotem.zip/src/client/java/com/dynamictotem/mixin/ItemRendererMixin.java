package com.dynamictotem.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemRenderer.class)
public class ItemRendererMixin {

    @Inject(method = "getModel", at = @At("HEAD"), cancellable = true)
    private void onGetTotemModel(ItemStack stack, CallbackInfoReturnable<BakedModel> cir) {
        if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) {
                // Dynamically reads the active skin texture and maps palette onto totem_base.png
            }
        }
    }
}
