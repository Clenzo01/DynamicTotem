package com.dynamictotem;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DynamicTotemClient implements ClientModInitializer {
    public static final String MOD_ID = "dynamictotem";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Dynamic Skin Totem Mod!");
    }
}
